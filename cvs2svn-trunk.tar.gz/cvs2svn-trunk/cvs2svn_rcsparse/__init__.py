# This file causes Python to treat its containing directory it as a
# package.  Please note that the contents of this file differ from
# those of the __init__.py file distributed with ViewVC.

