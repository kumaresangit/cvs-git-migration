This directory is used by the symlinks() test.  The test creates a
symlink in this directory before starting cvs2svn.

This README file itself is ignored by cvs2svn because it doesn't end
in ",v".
