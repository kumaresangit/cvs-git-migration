This directory should be created when the addition of c.txt triggers
the creation of its parent.
