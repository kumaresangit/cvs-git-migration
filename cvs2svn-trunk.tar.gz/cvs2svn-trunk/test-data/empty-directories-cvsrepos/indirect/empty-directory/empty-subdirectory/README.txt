This directory should be created when its parent is created, namely
when c.txt is added.
