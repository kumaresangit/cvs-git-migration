This directory does not contain any RCS files, so if the
--include-empty-directories option is used it should be created in the
commit that initializes the repository.
