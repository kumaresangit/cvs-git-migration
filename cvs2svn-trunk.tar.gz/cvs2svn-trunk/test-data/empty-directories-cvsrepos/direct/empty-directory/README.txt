This empty directory should be created when b.txt is created.
