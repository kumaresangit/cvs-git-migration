This directory should be created when its parent directory is created,
namely when b.txt is added.
