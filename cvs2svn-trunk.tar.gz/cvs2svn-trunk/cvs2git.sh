for dir in /home/cvs/Repositories/*;
do cd /home/cvs/Repositories
PROJECT=`echo $dir | awk -F'/' {'print $5'}`;
cd /root/cvs2svn-trunk
python cvs2git --blobfile=cvs2git-tmp/git-blob.dat --dumpfile=cvs2git-tmp/git-dump.dat --username=cvs2git --fallback-encoding=UTF-8 $dir >> log/cvs_migration/$PROJECT.log;
cd cvs2git-tmp;
git init --bare $PROJECT.git;
cd $PROJECT.git;
cat ../git-blob.dat ../git-dump.dat | git fast-import;
git gc --prune=now;
done
